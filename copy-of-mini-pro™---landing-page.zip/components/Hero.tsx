
import React from 'react';
import { ArrowRight, Star, ShieldCheck, Zap, Sparkles } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 px-4 overflow-hidden bg-white">
      {/* Background Decorative Element */}
      <div className="absolute top-[-10%] left-[60%] w-[600px] h-[600px] bg-pink-100/50 blur-[120px] rounded-full -z-10" />
      
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
        <div className="text-center lg:text-left space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-100 border border-pink-200 text-pink-600 text-xs font-bold tracking-widest uppercase">
            <Sparkles className="w-3 h-3" /> BEST SELLER 2024
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold leading-[1.05] tracking-tight text-zinc-900">
            Il potere di uno Smartphone. <span className="text-gradient-brand">In formato Mini.</span>
          </h1>
          
          <p className="text-zinc-500 text-lg md:text-xl max-w-xl mx-auto lg:mx-0 font-medium leading-relaxed">
            Piccolo come una carta di credito, potente come il tuo attuale telefono. Il Mini Pro™ è il gadget virale che sta conquistando tutti. Android, Fotocamera HD e Face ID.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
            <a 
              href="#pricing" 
              className="w-full sm:w-auto px-10 py-5 bg-gradient-brand rounded-2xl text-white font-bold text-xl hover:scale-105 transition-transform flex items-center justify-center gap-2 shadow-2xl shadow-pink-500/40"
            >
              LO VOGLIO ORA <ArrowRight className="w-6 h-6" />
            </a>
            <div className="flex flex-col items-center lg:items-start gap-1">
              <div className="flex text-yellow-400">
                {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Scelto da 50.000+ persone</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center lg:justify-start items-center gap-6 pt-4 text-zinc-400 border-t border-zinc-100">
            <div className="flex items-center gap-2 text-sm font-semibold">
              <ShieldCheck className="w-5 h-5 text-green-500" /> Pagamento alla consegna
            </div>
            <div className="flex items-center gap-2 text-sm font-semibold">
              <Zap className="w-5 h-5 text-blue-500" /> Consegna in 24h
            </div>
          </div>
        </div>

        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-brand blur-[100px] opacity-10 group-hover:opacity-20 transition-opacity" />
          <div className="relative rounded-[3rem] p-4 bg-zinc-100 border-4 border-white shadow-2xl overflow-hidden">
             <img 
              src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1000&auto=format&fit=crop" 
              alt="Mini Pro Smartphone" 
              className="rounded-[2.5rem] w-full object-cover aspect-[4/5]"
            />
            {/* Overlay comparison */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/90 backdrop-blur px-6 py-3 rounded-2xl border border-zinc-200 shadow-xl font-black text-zinc-900 text-lg uppercase tracking-tighter transform rotate-[-5deg]">
              SOLO 3 POLLICI! 😱
            </div>
          </div>
          
          <div className="absolute -bottom-6 -right-6 bg-white border border-zinc-200 p-6 rounded-3xl shadow-2xl animate-pulse-slow">
            <p className="text-pink-600 font-black text-3xl italic tracking-tighter">€29,99</p>
            <p className="text-zinc-400 text-xs font-bold line-through tracking-wider">INVECE DI €59,99</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
