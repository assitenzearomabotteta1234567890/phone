
import React, { useState } from 'react';
import { ShoppingCart, Check, Clock, ShieldCheck, Heart } from 'lucide-react';

const Pricing: React.FC = () => {
  const [selectedColor, setSelectedColor] = useState('Nero');

  const colors = [
    { name: 'Nero', class: 'bg-zinc-900' },
    { name: 'Rosa', class: 'bg-pink-400' },
    { name: 'Blu', class: 'bg-blue-400' }
  ];

  return (
    <section id="pricing" className="py-24 bg-zinc-50">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white border-2 border-zinc-200 rounded-[3rem] overflow-hidden shadow-2xl relative">
          
          <div className="bg-gradient-brand py-4 text-center">
            <p className="text-white text-sm font-black tracking-[0.2em] uppercase">OFFERTA VALIDA SOLO PER OGGI</p>
          </div>
          
          <div className="p-8 md:p-14">
            <div className="flex flex-col md:flex-row justify-between items-start gap-8 mb-12">
              <div className="space-y-4">
                <h3 className="text-5xl font-black italic tracking-tighter text-zinc-900">MINI PRO™ GEN 2</h3>
                <div className="flex items-center gap-2 text-zinc-500 font-bold text-sm uppercase tracking-widest bg-zinc-100 px-3 py-1.5 rounded-full w-fit">
                   Android 10 • 16GB ROM • Face ID
                </div>
                
                <div className="pt-4 space-y-3">
                  <p className="text-sm font-black text-zinc-400 uppercase tracking-widest">Scegli il tuo colore:</p>
                  <div className="flex gap-4">
                    {colors.map((c) => (
                      <button 
                        key={c.name}
                        onClick={() => setSelectedColor(c.name)}
                        className={`group relative flex flex-col items-center gap-2 transition-all`}
                      >
                        <div className={`w-12 h-12 rounded-full ${c.class} shadow-inner border-2 ${selectedColor === c.name ? 'border-pink-600 scale-110 ring-4 ring-pink-100' : 'border-transparent opacity-60'}`} />
                        <span className={`text-[10px] font-bold uppercase tracking-widest ${selectedColor === c.name ? 'text-pink-600' : 'text-zinc-400'}`}>{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="text-right flex flex-col items-center md:items-end w-full md:w-auto">
                <div className="text-zinc-300 line-through text-2xl font-black italic tracking-tighter">€59,99</div>
                <div className="text-7xl font-black text-zinc-900 tracking-tighter italic">€29,99</div>
                <div className="bg-green-100 text-green-600 text-xs font-black py-2 px-4 rounded-full mt-4 uppercase tracking-[0.1em] border border-green-200 animate-pulse">
                  SALVI €30.00 (50%)
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-y-4 gap-x-12 mb-12 py-8 border-y border-zinc-100">
              {[
                "Spedizione Espressa GRATUITA",
                "Pagamento alla Consegna OK",
                "App store pre-installato",
                "Cover Protettiva INCLUSA",
                "Garanzia 2 anni Italiana",
                "Reso facile 30 giorni"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-zinc-600 font-semibold">
                  <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-green-600" />
                  </div>
                  {item}
                </div>
              ))}
            </div>

            <div className="space-y-6">
              <button className="w-full bg-gradient-brand py-7 rounded-[2rem] text-white text-3xl font-black tracking-tight hover:scale-[1.03] active:scale-95 transition-all shadow-2xl shadow-pink-500/40 flex items-center justify-center gap-4 uppercase italic">
                SÌ, LO VOGLIO ORA! <ShoppingCart className="w-8 h-8" />
              </button>
              
              <div className="flex flex-col items-center gap-4">
                <div className="flex items-center gap-6">
                   <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-bold uppercase tracking-widest">
                    <Clock className="w-4 h-4 text-pink-600" /> Ultime 14 unità rimaste
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-bold uppercase tracking-widest">
                    <ShieldCheck className="w-4 h-4 text-pink-600" /> Privacy Protetta
                  </div>
                </div>
                <div className="flex items-center gap-2 text-pink-600 font-black text-sm uppercase tracking-tighter">
                   <Heart className="w-4 h-4 fill-current" /> Acquistato da 42 persone nell'ultima ora
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 grayscale opacity-40 contrast-125">
          <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" className="h-5 mx-auto" alt="Paypal" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-5 mx-auto" alt="Visa" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-5 mx-auto" alt="Mastercard" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Apple_Pay_logo.svg" className="h-5 mx-auto" alt="Apple Pay" />
        </div>
      </div>
    </section>
  );
};

export default Pricing;
