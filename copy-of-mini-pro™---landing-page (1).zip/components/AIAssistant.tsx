
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
// Fix: Added 'Smartphone' to the lucide-react imports
import { Sparkles, MessageSquare, X, Send, Loader2, Smartphone } from 'lucide-react';

const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: `Sei un esperto assistente di vendita per Mini Pro™, il mini smartphone Android virale da 3 pollici. 
          Il tuo obiettivo è convincere l'utente dei vantaggi del prodotto: 
          1. Portabilità estrema (grande come una carta di credito).
          2. Funzionalità Android completa (WhatsApp, TikTok, etc).
          3. Perfetto come regalo per bambini o come telefono di backup.
          4. Prezzo incredibile: €29.99 (sconto 50% solo oggi).
          5. Disponibile in Nero, Rosa e Blu.
          
          Rispondi in modo energico, giovane e persuasivo in italiano. Usa emoji. 
          Se chiedono del pagamento, dì che accettiamo pagamento alla consegna, PayPal e carte.`,
        },
      });

      setMessages(prev => [...prev, { role: 'model', text: response.text || "Scusa, sono troppo emozionato per rispondere! Il Mini Pro è pazzesco!" }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Il Mini Pro è così richiesto che la mia linea è un po' lenta! Ti garantisco però che è il miglior gadget dell'anno!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="w-[350px] sm:w-[400px] h-[500px] bg-white border border-zinc-200 rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-gradient-brand p-5 flex items-center justify-between text-white">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              <span className="font-black italic">Mini Pro Support</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:rotate-90 transition-transform"><X className="w-5 h-5" /></button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 && (
              <div className="text-center text-zinc-400 text-sm mt-10 space-y-2">
                <Smartphone className="w-12 h-12 mx-auto mb-4 opacity-20 text-zinc-900" />
                <p className="font-bold uppercase tracking-widest text-zinc-900">Ehi! Sono qui per aiutarti.</p>
                <p className="font-medium">Chiedimi cosa puoi fare con il Mini Pro!</p>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-3xl text-sm font-medium ${m.role === 'user' ? 'bg-pink-600 text-white shadow-lg' : 'bg-zinc-100 text-zinc-900'}`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-zinc-100 p-4 rounded-3xl">
                  <Loader2 className="w-4 h-4 animate-spin text-pink-600" />
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-zinc-100 flex gap-2">
            <input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Fai una domanda sul Mini Pro..."
              className="flex-1 bg-zinc-50 border border-zinc-200 rounded-2xl px-5 py-3 text-sm font-semibold focus:outline-none focus:border-pink-500 transition-colors"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading}
              className="bg-zinc-900 p-3 rounded-2xl text-white hover:bg-black transition-colors disabled:opacity-50 shadow-lg"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-gradient-brand w-16 h-16 rounded-full flex items-center justify-center text-white shadow-2xl shadow-pink-500/50 hover:scale-110 transition-transform group"
        >
          <MessageSquare className="w-8 h-8 group-hover:rotate-12 transition-transform" />
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full animate-pulse" />
        </button>
      )}
    </div>
  );
};

export default AIAssistant;
