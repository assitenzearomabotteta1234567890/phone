
import React from 'react';
import { Maximize, Shield, Zap, Globe, Cpu, Layout } from 'lucide-react';

const Features: React.FC = () => {
  const items = [
    {
      icon: <Maximize className="w-6 h-6" />,
      title: "Design Ultra-Compatto",
      desc: "L'unico telefono che scompare nella tua tasca. Perfetto per lo sport, i viaggi o come secondo dispositivo."
    },
    {
      icon: <Layout className="w-6 h-6" />,
      title: "Display HD 3.0\"",
      desc: "Colori brillanti e touch ultra-reattivo. Guarda video, naviga sui social e gioca senza limiti."
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Face Recognition",
      desc: "Sblocca il tuo mondo in un istante. Sicurezza biometrica avanzata integrata nella fotocamera frontale."
    },
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Android 10.0",
      desc: "Tutte le tue app preferite: WhatsApp, TikTok, Instagram e YouTube già pronte all'uso."
    },
    {
      icon: <Cpu className="w-6 h-6" />,
      title: "Dual SIM & Quad-Core",
      desc: "Due numeri in un solo mini-telefono. Processore fluido per un multitasking senza interruzioni."
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Batteria Long-Life",
      desc: "Ricarica veloce USB-C e autonomia che ti accompagna tutto il giorno nonostante le dimensioni."
    }
  ];

  return (
    <section id="features" className="py-24 bg-zinc-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-black tracking-tight text-zinc-900 uppercase italic">Piccolo corpo, <span className="text-gradient-brand">Grande Anima.</span></h2>
          <p className="text-zinc-500 max-w-2xl mx-auto font-medium">Non farti ingannare dalle dimensioni. Il Mini Pro™ racchiude la tecnologia più avanzata in un design iper-portatile.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, idx) => (
            <div key={idx} className="p-10 rounded-[2.5rem] bg-white border border-zinc-200 hover:shadow-xl transition-all group hover:-translate-y-2">
              <div className="w-14 h-14 rounded-2xl bg-zinc-100 flex items-center justify-center text-zinc-900 mb-8 group-hover:bg-gradient-brand group-hover:text-white transition-all shadow-inner">
                {item.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4 text-zinc-900">{item.title}</h3>
              <p className="text-zinc-500 text-sm font-medium leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
