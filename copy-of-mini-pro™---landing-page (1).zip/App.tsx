
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import AIAssistant from './components/AIAssistant';
import { Instagram, Twitter, Facebook, Youtube } from 'lucide-react';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main>
        <Hero />
        
        {/* Urgent/Social Stats Bar */}
        <div className="bg-zinc-900 py-8 border-y border-zinc-800">
          <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-around gap-10 text-center">
            <div>
              <p className="text-3xl font-black text-white italic tracking-tighter">50K+</p>
              <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] font-black mt-1">Venduti quest'anno</p>
            </div>
            <div>
              <p className="text-3xl font-black text-white italic tracking-tighter">98%</p>
              <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] font-black mt-1">Soddisfazione</p>
            </div>
            <div>
              <p className="text-3xl font-black text-white italic tracking-tighter">24H</p>
              <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] font-black mt-1">Consegna Fast</p>
            </div>
            <div className="hidden sm:block">
              <p className="text-3xl font-black text-white italic tracking-tighter">ZERO</p>
              <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] font-black mt-1">Costi Spedizione</p>
            </div>
          </div>
        </div>

        <Features />
        
        {/* Viral TikTok/Social Section */}
        <section className="py-24 px-4 bg-white relative overflow-hidden">
           <div className="absolute top-1/2 left-0 w-full h-[50%] bg-zinc-50 -z-10 transform -skew-y-2" />
          
          <div className="max-w-5xl mx-auto text-center space-y-12">
            <div className="space-y-4">
               <h2 className="text-4xl md:text-7xl font-black italic tracking-tighter text-zinc-900 uppercase">VIRALE SU TIKTOK 🚀</h2>
               <p className="text-zinc-500 font-bold uppercase tracking-widest text-sm">Milioni di visualizzazioni. Tutti ne vogliono uno.</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8 items-center">
               <div className="aspect-[9/16] bg-zinc-900 rounded-[3rem] border-8 border-zinc-100 shadow-2xl overflow-hidden relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?q=80&w=1000&auto=format&fit=crop" 
                    alt="Social Viral" 
                    className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-10 text-left">
                     <p className="text-white font-black italic text-2xl tracking-tighter uppercase mb-2">"Il regalo che tutti i miei amici mi invidiano!"</p>
                     <p className="text-pink-500 font-bold text-sm">@marty_lifestyle</p>
                  </div>
               </div>

               <div className="space-y-10 text-left md:pl-10">
                  <div className="space-y-4">
                     <h3 className="text-3xl font-black text-zinc-900 uppercase italic leading-none">Non è un giocattolo.<br/>È il futuro.</h3>
                     <p className="text-zinc-500 font-medium leading-relaxed">Il Mini Pro™ è diventato il gadget tech più desiderato dell'anno. Unisce l'estetica iconica degli smartphone moderni a una portabilità mai vista prima. Usalo come telefono secondario, regalalo ai tuoi figli o portalo in discoteca per avere le mani libere!</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 p-4 bg-white rounded-2xl border border-zinc-100 shadow-sm">
                       <div className="w-12 h-12 bg-zinc-100 rounded-xl flex items-center justify-center font-black text-zinc-900 italic">01</div>
                       <div>
                          <p className="font-black text-zinc-900 uppercase tracking-tighter">100% Funzionalità</p>
                          <p className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Play Store integrato</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-4 p-4 bg-white rounded-2xl border border-zinc-100 shadow-sm">
                       <div className="w-12 h-12 bg-zinc-100 rounded-xl flex items-center justify-center font-black text-zinc-900 italic">02</div>
                       <div>
                          <p className="font-black text-zinc-900 uppercase tracking-tighter">Stile Iconico</p>
                          <p className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Materiali premium</p>
                       </div>
                    </div>
                  </div>

                  <a href="#pricing" className="inline-block bg-zinc-900 text-white px-10 py-5 rounded-2xl font-black italic tracking-tighter uppercase hover:bg-pink-600 transition-colors shadow-xl shadow-zinc-200">
                    SCOPRI IL PREZZO SPECIALE 💸
                  </a>
               </div>
            </div>
          </div>
        </section>

        <Testimonials />
        <Pricing />
        
        {/* Final CTA Bar */}
        <div className="bg-gradient-brand py-12 px-4">
           <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="text-center md:text-left text-white">
                 <h2 className="text-4xl font-black italic tracking-tighter uppercase leading-none">Cosa stai aspettando?</h2>
                 <p className="text-white/80 font-bold uppercase tracking-widest text-sm mt-2">L'offerta al 50% scade tra pochi minuti.</p>
              </div>
              <a href="#pricing" className="bg-white text-zinc-900 px-12 py-5 rounded-full font-black italic tracking-tighter uppercase shadow-2xl hover:scale-105 transition-transform">
                ORDINA MINI PRO™ ORA
              </a>
           </div>
        </div>
      </main>

      <footer className="bg-white border-t border-zinc-200 py-16">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="font-extrabold text-2xl tracking-tighter uppercase italic text-zinc-900">Mini Pro</div>
            <p className="text-zinc-500 text-sm font-medium leading-relaxed">Ridefiniamo il concetto di smartphone. La tecnologia più avanzata nel palmo della tua mano.</p>
            <div className="flex gap-4">
              <Instagram className="w-5 h-5 text-zinc-400 hover:text-pink-600 transition-colors cursor-pointer" />
              <Twitter className="w-5 h-5 text-zinc-400 hover:text-pink-600 transition-colors cursor-pointer" />
              <Facebook className="w-5 h-5 text-zinc-400 hover:text-pink-600 transition-colors cursor-pointer" />
              <Youtube className="w-5 h-5 text-zinc-400 hover:text-pink-600 transition-colors cursor-pointer" />
            </div>
          </div>
          
          <div>
            <h4 className="font-black text-zinc-900 uppercase italic tracking-tighter mb-6">Supporto</h4>
            <ul className="text-sm text-zinc-500 space-y-3 font-bold uppercase tracking-wider">
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Traccia il mio ordine</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Contattaci</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Resi e Rimborsi</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">FAQ</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-black text-zinc-900 uppercase italic tracking-tighter mb-6">Info Legali</h4>
            <ul className="text-sm text-zinc-500 space-y-3 font-bold uppercase tracking-wider">
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Privacy Policy</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Cookie Policy</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Termini di Servizio</li>
              <li className="hover:text-pink-600 cursor-pointer transition-colors">Pagamenti Sicuri</li>
            </ul>
          </div>

          <div>
            <h4 className="font-black text-zinc-900 uppercase italic tracking-tighter mb-6">VIP List</h4>
            <p className="text-sm text-zinc-500 mb-6 font-medium">Ricevi coupon segreti e nuovi gadget tech.</p>
            <div className="space-y-2">
              <input className="bg-zinc-100 border border-zinc-200 rounded-xl px-4 py-3 text-sm w-full focus:outline-none font-bold" placeholder="La tua migliore email" />
              <button className="bg-zinc-900 text-white w-full py-3 rounded-xl text-xs font-black uppercase italic tracking-widest hover:bg-pink-600 transition-colors">UNISCITI</button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 pt-16 mt-16 border-t border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-zinc-400 font-bold uppercase tracking-widest">
          <p>&copy; {new Date().getFullYear()} Mini Pro™ Italia. Tutti i diritti riservati.</p>
          <p>Design di Alta Conversione</p>
        </div>
      </footer>

      {/* Floating UI Elements */}
      <AIAssistant />
      
      {/* Live Sales Notification */}
      <div className="fixed bottom-6 left-6 z-50 hidden md:block">
        <div className="bg-white border border-zinc-200 p-5 rounded-[2rem] flex items-center gap-4 shadow-2xl animate-in fade-in slide-in-from-left-4 duration-1000">
          <div className="relative">
            <img src="https://i.pravatar.cc/100?u=vincenzo" className="w-12 h-12 rounded-full border-2 border-pink-100" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
          </div>
          <div className="text-[11px] font-bold">
            <p className="text-zinc-400 italic">Vincenzo D. da Napoli</p>
            <p className="text-zinc-900 uppercase tracking-tighter">ha appena ordinato il <span className="text-pink-600">Mini Pro Nero!</span> 🔥</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
